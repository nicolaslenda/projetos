//arruma a função da primeira luta que ta com problema na hora de atacar e defender
let vida = 100;
let inventario = [];
const nome = "Cindy";
let pontos = 0; 
let vidaInimigoUm = 400
let vidaInimigoDois = 600
let vidaInimigoTres = 1000
let ultimoinimigo = 6000
let vidaMaxima = 100
function rolarDado(){
    //gera um número aleatório entre 1 e 20
    return Math.floor(Math.random() * 20) + 1;
}
//função para exibir o inventário e usar algum item
function exibirInventario() {
    alert("Inventário atual: " + inventario);    
    return
}
//função para recuperação de vida
function interagirComUsuario() {
    exibirInventario();
    let itemParaUsar = Number(prompt("voce gostaria de usar memorias boas(1) ou memorias fortes(0)?"));
    
    switch (itemParaUsar) {
        case 1:
        alert("voce recuperou 10 de vida")
        vida += 10
        break;
        case 0:
            alert("voce recuperou 30 de vida")
            vida+= 30
            break;
        default:
            alert("Item inválido. Por favor, escolha entre boas ou forte.");
            break;
    }
    alert("Você usou uma memoria que lhe lembrou do porque esta aqui. Agora você tem " + vida + " de vida.");
return
}
  function atacar(){
    let dado = rolarDado();
    let danoBase = 20;
    let parte = Number(prompt("1- cabeça\n2-torso\n3-braço esquerdo\n4-braço direito"))
    switch(parte){
        case 1:
            if (dado >= 15) {
                danoBase *= 1.5;//dano aumentado para a cabeça
                vidaInimigoUm -= danoBase
                alert("voce acertou")
                danoBase = 20
                
            }else {
                alert("voce acertou de raspao")
                danoBase = 10
                vidaInimigoUm -= danoBase
                danoBase = 20
            }
            break;
        case 2:
            if (dado >= 10) {
                danoBase *= 1;//dano normal para o torso
                vidaInimigoUm -= danoBase
                alert("voce acertou")
                danoBase = 20
            }else{
                alert("voce acertou de raspao")
                danoBase = 10
                vidaInimigoUm -= danoBase
                danoBase = 20
            }
            break;
        case 3:
            if(dado >=11){
                danoBase *= 1.1
                alert("voce acertou")
                vidaInimigoUm -= danoBase
            }
            else{
                alert("voce acertou de raspao")
                danoBase = 10
                vidaInimigoUm -= danoBase
                danoBase = 20
            }
        case 4:
            if (dado >= 11) {
                danoBase *= 1.1;//dano aumentado para os braços
                vidaInimigoUm -= danoBase
                alert("voce acertou")
            }else{
                alert("voce acertou de raspao")
                danoBase = 10
                vidaInimigoUm -= danoBase
                danoBase = 20
            }
            break;
        default:
            alert("opção invalida")
            atacar()
            break;
    }   
        atacarInimigoUm()
}
function atacarInimigoUm(){
    //função para definir se o inimigo acerta ou não
    if(rolarDado() < 10){
        alert("o inimigo errou")
    }
    else{
alert("o inimigo acertou")
vida-= 10
    }
    return rolarDado()
}
function recuperacaoVida(){
    //funçao para recuperação de vida
    opcaocura = Number(prompt("voce quer usar memorias boas(0) ou memorias fortes(1)?"))
    if(opcaocura =0 && inventario.includes("memorias boas")){
        vida += 10
        alert("voce recuperou 25 de vida")
    }
    if(opcaocura =1 && inventario.includes("memorias de força")){
        vida += 30
        alert("voce recuperou 40 de vida")
    }
    else{
alert("opção invalida")
    }return
}
function primeiraLuta(){
    //define como vai ser a primeira luta e irei usar de exemplo no resto do jogo   
    let turno = 1
    while (vidaInimigoUm > 0) {
        if (turno % 2 !== 0) {
            //turno do usuário
            let acao = prompt(`Você está com ${vida} de vida e o inimigo está com ${vidaInimigoUm} de vida.\nEscolha sua ação:\n1. Atacar\n2. Defender\n3. Recuperar Vida`);
            if (acao === "1") {
                atacar();
            } else if (acao === "2") {
                alert("Você defendeu o ataque.");
            } else if (acao === "3") {
                interagirComUsuario()
                if (vida > vidaMaxima) {
                    vida = vidaMaxima;//limita a vida máxima
                }
            } else {
                alert("Ação inválida. Por favor, escolha 1 para atacar, 2 para defender, ou 3 para recuperar vida.");
                continue;//pular o turno se a ação for inválida
            }
            if (vidaInimigoUm <= 0) {
                alert("Parabéns! Você ganhou.");
                break;
            }
        } else {
            //turno do inimigo
            atacarInimigoUm
            if (vida <= 0) {
                alert("Você foi derrotado pelo inimigo.");
                vida = 100
                vidaInimigoUm = 400
                break;
            }
        }
        turno++;//passa para o próximo turno
    }return
}
function segundaLuta(){
    let turno = 1
    let vida = 100
    while (vidaInimigoDois > 0) {
        if (turno % 2 !== 0) {
            //turno do usuário
            let acao = prompt(`Você está com ${vida} de vida e o inimigo está com ${vidaInimigoDois} de vida.\nEscolha sua ação:\n1. Atacar\n2. Defender\n3. Recuperar Vida`);
            if (acao === "1") {
                atacarDois();
            } else if (acao === "2") {
                alert("Você defendeu o ataque.");
            } else if (acao === "3") {
                interagirComUsuario()
                if (vida > vidaMaxima) {
                    vida = vidaMaxima;//limita a vida máxima
                }
            } else {
                alert("Ação inválida. Por favor, escolha 1 para atacar, 2 para defender, ou 3 para recuperar vida.");
                continue;//pular o turno se a ação for inválida
            }
            if (vidaInimigoTres <= 0) {
                alert("Parabéns! Você ganhou.");
                break;
            }
        } else {
            //turno do inimigo
            atacarInimigoUm
            if (vida <= 0) {
                alert("Você foi derrotado pelo inimigo.");
                vida = 100
                vidaInimigoDois = 600
                break;
            }
        }
        turno++;//passa para o próximo turno
    }return
}
function atacarDois(){
    let dado = rolarDado();
    let danoBase = 20;
    let parte = Number(prompt("1- cabeça\n2-torso\n3-braço esquerdo\n4-braço direito"))
    switch(parte){
        case 1:
            if (dado >= 15) {
                danoBase *= 1.5;//dano aumentado para a cabeça
                vidaInimigoDois -= danoBase
                alert("voce acertou")
                danoBase = 20
                
            }else {
                alert("voce acertou de raspao")
                danoBase = 10
                vidaInimigoDois -= danoBase
                danoBase = 20
            }
            break;
        case 2:
            if (dado >= 10) {
                danoBase *= 1;//dano normal para o torso
                vidaInimigoDois -= danoBase
                alert("voce acertou")
                danoBase = 20
            }else{
                alert("voce acertou de raspao")
                danoBase = 10
                vidaInimigoDois -= danoBase
                danoBase = 20
            }
            break;
        case 3:
            if(dado >=11){
                danoBase *= 1.1
                alert("voce acertou")
                vidaInimigoDois -= danoBase
            }
            else{
                alert("voce acertou de raspao")
                danoBase = 10
                vidaInimigoDois -= danoBase
                danoBase = 20
            }
        case 4:
            if (dado >= 11) {
                danoBase *= 1.1;//dano aumentado para os braços
                vidaInimigoDois -= danoBase
                alert("voce acertou")
            }else{
                alert("voce acertou de raspao")
                danoBase = 10
                vidaInimigoDois -= danoBase
                danoBase = 20
            }
            break;
        default:
            alert("opção invalida")
            atacarDois()
            break;
    }   
        atacarInimigoUm()
}
function terceiraLuta(){
    let turno = 1
    let vida = 100
    while (vidaInimigoDois > 0) {
        if (turno % 2 !== 0) {
            //turno do usuário
            let acao = prompt(`Você está com ${vida} de vida e o inimigo está com ${vidaInimigoTres} de vida.\nEscolha sua ação:\n1. Atacar\n2. Defender\n3. Recuperar Vida`);
            if (acao === "1") {
                atacarTres();
            } else if (acao === "2") {
                alert("Você defendeu o ataque.");
            } else if (acao === "3") {
                interagirComUsuario()
                if (vida > vidaMaxima) {
                    vida = vidaMaxima;//limita a vida máxima
                }
            } else {
                alert("Ação inválida. Por favor, escolha 1 para atacar, 2 para defender, ou 3 para recuperar vida.");
                continue;//pular o turno se a ação for inválida
            }
            if (vidaInimigoTres <= 0) {
                alert("Parabéns! Você ganhou.");
                break;
            }
        } else {
            //turno do inimigo
            atacarInimigoUm
            if (vida <= 0) {
                alert("Você foi derrotado pelo inimigo.");
                vida = 100
                vidaInimigoTres = 1000
                break;
            }
        }
        turno++;//passa para o próximo turno
    }return
}
function atacarTres(){
    let dado = rolarDado();
    let danoBase = 20;
    let parte = Number(prompt("1- cabeça\n2-torso\n3-braço esquerdo\n4-braço direito"))
    switch(parte){
        case 1:
            if (dado >= 15) {
                danoBase *= 1.5;//dano aumentado para a cabeça
                vidaInimigoTres -= danoBase
                alert("voce acertou")
                danoBase = 20
                
            }else {
                alert("voce acertou de raspao")
                danoBase = 10
                vidaInimigoTres -= danoBase
                danoBase = 20
            }
            break;
        case 2:
            if (dado >= 10) {
                danoBase *= 1;//dano normal para o torso
                vidaInimigoTres -= danoBase
                alert("voce acertou")
                danoBase = 20
            }else{
                alert("voce acertou de raspao")
                danoBase = 10
                vidaInimigoTres -= danoBase
                danoBase = 20
            }
            break;
        case 3:
            if(dado >=11){
                danoBase *= 1.1
                alert("voce acertou")
                vidaInimigoTres -= danoBase
            }
            else{
                alert("voce acertou de raspao")
                danoBase = 10
                vidaInimigoTres -= danoBase
                danoBase = 20
            }
        case 4:
            if (dado >= 11) {
                danoBase *= 1.1;//dano aumentado para os braços
                vidaInimigoTres -= danoBase
                alert("voce acertou")
            }else{
                alert("voce acertou de raspao")
                danoBase = 10
                vidaInimigoTres -= danoBase
                danoBase = 20
            }
            break;
        default:
            alert("opção invalida")
            atacarTres()
            break;
    }   
        atacarInimigoUm()
}
function lutaFinal(){
    let turno = 1
    while (vida > 0) {
        if (turno % 2 !== 0) {
            //turno do usuário
            let acao = prompt(`Você está com ${vida} de vida e o inimigo está com ${ultimoinimigo} de vida.\nEscolha sua ação:\n1. Atacar\n2. Defender\n3. Recuperar Vida`);
            if (acao === "1") {
                ultimoAtaque();
            } else if (acao === "2") {
                alert("Você defendeu o ataque.");
            } else if (acao === "3") {
                interagirComUsuario()
                if (vida > vidaMaxima) {
                    vida = vidaMaxima;//limita a vida máxima
                }
            } else {
                alert("Ação inválida. Por favor, escolha 1 para atacar, 2 para defender, ou 3 para recuperar vida.");
                continue;//pular o turno se a ação for inválida
            }
            if (ultimoinimigo <= 0) {
                alert("Parabéns! Você ganhou.");
                break;
            }
        } else {
            //turno do inimigo
            atacarInimigoUm
            if (vida <= 0) {
                alert("Você foi derrotado pelo inimigo.");
                vida = 100
                ultimoinimigo = 1000
                break;
            }
        }
        turno++;//passa para o próximo turno
    }return
}
function ultimoAtaque(){
    let dado = rolarDado();
    let danoBase = 20;
    let parte = Number(prompt("1- cabeça\n2-torso\n3-braço esquerdo\n4-braço direito"))
    switch(parte){
        case 1:
            if (dado >= 15) {
                danoBase *= 1.5;//dano aumentado para a cabeça
                ultimoinimigo -= danoBase
                alert("voce acertou")
                danoBase = 20
                
            }else {
                alert("voce acertou de raspao")
                danoBase = 10
                ultimoinimigo -= danoBase
                danoBase = 20
            }
            break;
        case 2:
            if (dado >= 10) {
                danoBase *= 1;//dano normal para o torso
                ultimoinimigo -= danoBase
                alert("voce acertou")
                danoBase = 20
            }else{
                alert("voce acertou de raspao")
                danoBase = 10
                ultimoinimigo -= danoBase
                danoBase = 20
            }
            break;
        case 3:
            if(dado >=11){
                danoBase *= 1.1
                alert("voce acertou")
                ultimoinimigo -= danoBase
            }
            else{
                alert("voce acertou de raspao")
                danoBase = 10
                ultimoinimigo -= danoBase
                danoBase = 20
            }
        case 4:
            if (dado >= 11) {
                danoBase *= 1.1;//dano aumentado para os braços
                ultimoinimigo -= danoBase
                alert("voce acertou")
            }else{
                alert("voce acertou de raspao")
                danoBase = 10
                ultimoinimigo -= danoBase
                danoBase = 20
            }
            break;
        default:
            alert("opção invalida")
            ultimoAtaque()
            break;
    }   
        atacarInimigoUm()
}
alert("voce é Cindy Ngamba, atualmente voce tem 11 anos, jovem, não?")
alert("atualmente voce vive numa vila em algum lugar de camaroes")
alert("voce sente dentro de voce uma vontade de ser melhor.")
alert("voce recebeu memorias boas")
inventario.push("memorias boas")
alert("sua vida é sempre repetitiva, ajudar seu pai, mãe e irmaos a conseguir dinheiro ou ajudar em problemas de casa, isso continuou ate os seus 11 anos.")
alert("um certo dia, seu irmao lhe convida a mudar de vida, mudar de país, recomeçar tudo.")
escolhaum=prompt("voce aceita(0) ou rejeita(1)?")
//rota diferente
if(escolhaum == 1){
alert("após rejeitar a proposta de seu irmão, ele se foi, você não sabe o que aconteceu com ele.")
alert("você continuou ajudando seus pais no trabalho e em casa.")
alert("a cada dia você se pergunta, e se eu tivesse aceitado? eu estaria em uma vida melhor? morreria por fome ou questões climáticas? financeiras? sozinha?")
alert("após alguns anos você não se lembra do rosto do irmão, você se sente triste por ter perdido os pais por uma doença, você não sabe o que fazer mais.")
alert("ir contra a vida? não, você não desistiria tão facilmente.")
alert("você resolve sair da vila para tentar conseguir um bom emprego em uma cidade grande, dinheiro é a sua maior preocupação.")
alert("porem não se é muito saudável viver nas ruas, e por doença e fome, em uma vida triste e sozinha, sua historia se acaba, como mais uma pessoa comum.")
alert("!PARABENS PELO FINAL TRISTE!")
}
alert("voce aceitou, porem não é por que voce saiu de camaroes que tua vida vai melhorar, junto com o seu irmão, voces vivem uma vida de mizeria nas ruas do Reino Unido.")
alert("voce esta preocupada com o seu destino, para onde voce irá? como vai sobreviver?")
alert("pensando no assunto, voce poderia se afastar de seu irmão ou continuar")
escolhadois = prompt("ficar longe dele(0) ou continuar com ele(1)")
//rota diferente
if(escolhadois==0){
    alert("agora longe dele, você não sabe o que deve fazer, você se sente solitária.")
    alert("enquanto você dormia nas em cima de uma ponte, um motorista bêbado quase lhe atropela, por sorte nada acontece com você, porem pelo susto você tropeça para o meio das ruas, porem não morre.")
    alert("ao passar dos dias, a fome te consome, sua visão esta turva, será isso a morte por fome? porem você não sente nada, por conta da adrenalina do momento, você não havia percebido que pisou em um prego enferrujado, você esta enjoada e sua visão se acaba.")
    alert("!PARABENS VOCE FEZ O FINAL TRISTE!")
}
alert("voce e seu irmão acharam um orfanato, por serem crianças que se separaram dos seus pais, voces vivem por um tempo no orfanato.")
alert("a vida não era a melhor, como viver como uma rainha, mas definitivamente era melhor do que as ruas.")
alert("toda vez que algum adulto chega no orfanato para adotar alguma criança, voce sempre arranja uma maneira para chegar proxima a porta da diretora.")
alert("um dia, voce ve 2 pessoas chegarem no orfanato, como de costume, voce chega perto da porta para ouvir a conversa, durante os 4 anos que voce esteve no orfanato, voce aprendeu pelo menos um pouco de inglês, ao o que voce entendeu, estavam pensando em lhe adotar.")
alert("voce recebeu pelo tempo que ficou no orfanato 5 memorias boas")
inventario.push("memorias boas")
inventario.push("memorias boas")
inventario.push("memorias boas")
inventario.push("memorias boas")
inventario.push("memorias boas")
alert("mais tarde no mesmo dia, as mesmas duas pessoas chegam em voce e dizem:")
alert("ja assinamos os documentos, voce quer vir morar com nós?")
alert("voce ate se lembra do seu irmao, parando para pensar, nesse ultimo ano, voce não viu muito seu irmao.\npensando um pouco, voce aceita.")
alert("voce descobre que seu pai é dono de um ginasio de boxe, e sua mae ajuda na parte financeira.")
alert("2 meses apos voce morar com seus novos pais, voce pensa em perguntar a eles sobre participar do boxe.")
escolhatres=prompt("voce quer perguntar(1) ou deixar de lado(0)?")
//rota diferente
if(escolhatres == 0){
    alert("você deixa de lado a pergunta para o seu pai e mãe, você acha que é desnecessário o boxe para sua vida.")
    alert("você estuda muito para poder estudar em uma boa faculdade, você se forma e deixa seus pais orgulhosos.")
    alert("com o tempo você sente que falta algo, um amor? força? inteligência? seria a solidão? você não sabe.")
    alert("você teve uma boa vida, assim como seus pais, você decide adotar uma criança.")
    alert("os anos se passam, antes a sua criança doce, antes uma adolescente rebelde, agora uma adulta, você se aposenta, vê seus netos, porem, na morte, você se sente vazia, sente que não fez o que amava, porem não esta arrependida.")
    alert("!PARABENS PELO FINAL MEDIANO, ESSE FINAL É BEM TRISTE TALVEZ!")
}
alert("ao perguntar aos seus pais, eles aceitam orgulhosamente voce ir no ginasio.")
alert("o ginasio é um pouco barulhento, por sorte é dia de treino, seu pai te ensina o basico, postura, como socar, tipos de socos, regras etc. voce ama tudo isso, voce ama seus pais.")
alert("enquanto voce assistia tv, seu pai pergunta:\nfilha, voce gosta de boxe, gostaria de ver comigo as olimpiadas?")
alert("voce se pergunta o que seria as olimpiadas.")
escolhaquatro=prompt("voce aceita(0) ou recusa(1)?")
//rota diferente
if(escolhaquatro == 1){
    alert("você recusa, não parece ser interessante.")
    alert("seu pai aceita a resposta e decide ver o torneio de boxe que você estava assistindo na tv junto com você.")
    alert("o seu interesse por boxe é incrível, se tornando uma lutadora e campeã de alguns torneios de boxe, você sente que podia mais.")
    alert("enquanto andava pelas ruas, após um torneio, você decide descansar em uma escada. aquela luta foi incrível, foi a mais difícil que você teve, uma oponente realmente forte, alta, e tinha........ o que?")
    alert("aquela escada não estava muito boa para um humano sentar por muito tempo, e você nem percebeu que atras de você não tinha proteção para pessoas caírem, tentando se proteger da queda, você bate a cabeça.")
    alert("seus pais a procuram por dias, porem não a encontram.")
    alert("!ESSE FINAL ELA FEZ O QUE AMAVA, POREM FOI A QUE CUSTO?!")
}
alert("voce recebeu 3 memorias boas por ficar com seu pai")
inventario.push("memorias boas")
inventario.push("memorias boas")
inventario.push("memorias boas")
alert("as olimpiadas, que esporte maravilhoso, voce jura a seu pai que um dia, iria as olimpiadas e ganharia um medalha para orgulhalos.")
alert("porem voce precisa treinar. nos seus 17 anos voce decide participar de um campeonato, voce não sente dificuldade alguma ao lutar com suas primeiras oponentes oponentes.")
alert("nas semi-finais, sua oponente parece estar convicta que irá ganhar, ela vai ser extremamente dificil de ganhar.")
alert("ela possui 1,77 metros, claramente maior que voce, isso é realmente uma mulher? fora que ela ta no limite do peso leve, porem voce vai dar tudo de si.")
alert("voce recebeu resistencia de soldado e 10 memorias de força")
inventario.push("memorias de força")
inventario.push("memorias de força")
inventario.push("memorias de força")
inventario.push("memorias de força")
inventario.push("memorias de força")
inventario.push("memorias de força")
inventario.push("memorias de força")
inventario.push("memorias de força")
inventario.push("memorias de força")
inventario.push("memorias de força")
alert("nas lutas voce pode utilizar a memorias de força e memorias boas para recuperar sua vida, também pode usar a resistencia de soldado para diminuir o dano recebido do oponente e futuramente algumas habilidades de uso unico ou quando usadas irão diminuir sua vida. boa sorte")
primeiraLuta()
alert("as finais não foram tao dificeis quanto a sua luta anterior, porem voce ainda sente que pode ganhar mais campeonatos.")
alert("apos ganhar, voce precisa mostrar essa conquista aos seus pais, como forma de orgulho, seus pais montam um banquete.durante o banquete voce agradece a eles por terem a adotado.")
inventario.push("memorias boas")
inventario.push("memorias boas")
inventario.push("memorias boas")
inventario.push("memorias boas")
inventario.push("memorias boas")
inventario.push("memorias boas")
inventario.push("memorias boas")
inventario.push("memorias boas")
inventario.push("memorias boas")
inventario.push("memorias boas")
inventario.push("memorias boas")
inventario.push("memorias boas")
inventario.push("memorias boas")
inventario.push("memorias boas")
inventario.push("memorias boas")
inventario.push("memorias boas")
inventario.push("memorias boas")
inventario.push("memorias boas")
inventario.push("memorias boas")
inventario.push("memorias boas")
alert("seu proximo objetivo é ganhar o campeonato de peso pena.")
alert("perder peso não sera seu problema, porem voce ira treinar.")
alert("durante as finais, sua oponente é de dar medo, com 1,60 metros, o perigo dela não esta na altura, e sim a força e durabilidade.")
segundaLuta()
alert("finalmente, voce se sente forte.")
alert("sua força foi reconhecida, e lhe chamam para participar das olimpiadas femininas como bandeirante dos refugiados.")
alert("todas as lutas foram extremamente dificeis, porem agora, voce ira disputar pelo bronze.")
alert("sua proxima luta sera contra a francesa Davina Michel na categoria 75 KG, para disputar o bronze.")
inventario.push("memorias de força")
terceiraLuta()
alert("voce foi a primeira dentre todos da equipe dos refugiados a conseguir uma medalha, não é a melhor mas ja vai virar historia.")
alert("esta luta foi a complicada, agora voce ira disputar para ir nas finais, sua proxima luta sera contra a panamenha Atheyna Bylon, ela é gigante, experiente e não parece que vai querer cair, com 35 anos, ela tem 1,79 metros, mesmo fora do auge humano, ela parece que não vai cair.")
lutaFinal()
alert("voce perdeu, realmente, voce queria ir além, pena que não foi dessa vez, porem voce fez muita coisa, tanta a ponto de entrar para a historia como a primeira a ganhar uma medalha para os refugiados, se orgulhe.")
